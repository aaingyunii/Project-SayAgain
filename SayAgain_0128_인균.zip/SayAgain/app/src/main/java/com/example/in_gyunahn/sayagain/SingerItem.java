package com.example.in_gyunahn.sayagain;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class SingerItem {

    String name;
    String mobile;
//    int resId;

    public SingerItem(String name, String mobile) {
        this.name = name;
        this.mobile = mobile;
//        this.resId = resId;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
//    public int getResId() {
//        return resId;
//    }

//    public void setResId(int resId) {
//        this.resId = resId;
//    }

    @Override
    public String toString() {
        return "SingerItem{" +
                "name='" + name + '\'' +
                ", mobile='" + mobile + '\'' +
                '}';
    }
}